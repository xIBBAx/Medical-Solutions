const sosBtn = document.querySelector(".sos-btn");
const backdrop = document.querySelector(".backdrop");

sosBtn.addEventListener("click", () => {
  backdrop.classList.toggle("hide");
});

function toggleBtn() {
  backdrop.classList.toggle("hide");
}
