<?php
session_start();
// include_once '../connection/server.php';
include_once '../assets/conn/dbconnect.php';
if(!isset($_SESSION['patientSession']))
{
header("Location: ../index.php");
}
$res=mysqli_query($con,"SELECT * FROM patient WHERE icPatient=".$_SESSION['patientSession']);
$userRow=mysqli_fetch_array($res,MYSQLI_ASSOC);
?>
<!-- update -->
<?php
if (isset($_POST['submit'])) {
//variables
$patientFirstName = $_POST['patientFirstName'];
$patientLastName = $_POST['patientLastName'];
$patientMaritialStatus = $_POST['patientMaritialStatus'];
$patientDOB = $_POST['patientDOB'];
$patientGender = $_POST['patientGender'];
$patientAddress = $_POST['patientAddress'];
$patientPhone = $_POST['patientPhone'];
$patientEmail = $_POST['patientEmail'];
$patientId = $_POST['patientId'];
// mysqli_query("UPDATE blogEntry SET content = $udcontent, title = $udtitle WHERE id = $id");
$res=mysqli_query($con,"UPDATE patient SET patientFirstName='$patientFirstName', patientLastName='$patientLastName', patientMaritialStatus='$patientMaritialStatus', patientDOB='$patientDOB', patientGender='$patientGender', patientAddress='$patientAddress', patientPhone=$patientPhone, patientEmail='$patientEmail' WHERE icPatient=".$_SESSION['patientSession']);
// $userRow=mysqli_fetch_array($res);
header( 'Location: profile.php' ) ;
}
?>
<?php
$male="";
$female="";
$other="";
if ($userRow['patientGender']=='male') {
$male = "checked";
}elseif ($userRow['patientGender']=='Other') {
	$other = "checked";

}elseif ($userRow['patientGender']=='female') {
$female = "checked";
}
$single="";
$married="";
$separated="";
$divorced="";
$widowed="";
if ($userRow['patientMaritialStatus']=='single') {
$single = "checked";
}elseif ($userRow['patientMaritialStatus']=='married') {
$married = "checked";
}elseif ($userRow['patientMaritialStatus']=='separated') {
$separated = "checked";
}elseif ($userRow['patientMaritialStatus']=='divorced') {
$divorced = "checked";
}elseif ($userRow['patientMaritialStatus']=='widowed') {
$widowed = "checked";
}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<title>Patient Dashboard</title>
		<!-- Bootstrap -->
		<link href="assets/css/bootstrap.min.css" rel="stylesheet">
		<link href="assets/css/default/style.css" rel="stylesheet">
		<link href="assets/style.css" rel="stylesheet">
		<!-- <link href="assets/css/default/style1.css" rel="stylesheet"> -->
		<link href="assets/css/default/blocks.css" rel="stylesheet">
		<link href="assets/css/date/bootstrap-datepicker.css" rel="stylesheet">
		<link href="assets/css/date/bootstrap-datepicker3.css" rel="stylesheet">
		<!-- Special version of Bootstrap that only affects content wrapped in .bootstrap-iso -->
		<link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" />
		<!--Font Awesome (added because you use icons in your prepend/append)-->
		<link rel="stylesheet" href="https://formden.com/static/cdn/font-awesome/4.4.0/css/font-awesome.min.css" />
		<!-- <link href="assets/css/material.css" rel="stylesheet"> -->
	</head>
	<body>
		
		<!-- navigation -->
		<nav class="navbar navbar-default " role="navigation">
			<div class="container-fluid">
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<ul class="nav navbar-nav">
							<li><a href="patient.php">Home</a></li>
							<!-- <li><a href="profile.php?patientId=<?php echo $userRow['icPatient']; ?>" >Profile</a></li> -->
							<li><a href="patientapplist.php?patientId=<?php echo $userRow['icPatient']; ?>">Appointment</a></li>
							<li><a href="insurance.php" target="_blank">Insurance</a></li>
						</ul>
					</ul>
					
					<ul class="nav navbar-nav navbar-right">
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo $userRow['patientFirstName']; ?> <?php echo $userRow['patientLastName']; ?><b class="caret"></b></a>
							<ul class="dropdown-menu">
								<li>
									<a href="profile.php?patientId=<?php echo $userRow['icPatient']; ?>"><i class="fa fa-fw fa-user"></i> Profile</a>
								</li>
								<li>
									<a href="patientapplist.php?patientId=<?php echo $userRow['icPatient']; ?>"><i class="glyphicon glyphicon-file"></i> Appointment</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="patientlogout.php?logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
								</li>
							</ul>
						</li>
					</ul>
				</div>
			</div>
		</nav>
		<!-- navigation -->
		
		<div class="container">
											<!-- Brand and toggle get grouped for better mobile display -->
				<form action="<?php $_PHP_SELF ?>" method="post">
				<div class="form-group">
					<label for="insurancePlan">Select Insurance Plan</label>
					<select class="form-control" id="insurancePlan" name="insurancePlan">
					<option value="Less than ₹20,000">Less than ₹50,000</option>
					<option value="₹21,000 - ₹50,000">₹50,000 - ₹1,00,000</option>
					<option value="Above ₹50,000">Above ₹1,00,000</option>
					</select>
				</div>
				</form>
			<section style="padding-bottom: 50px; padding-top: 50px;">
				<div class="row">
					<!-- start -->
					<!-- USER PROFILE ROW STARTS-->
					<div class="row">
						<div class="col-md-3 col-sm-3">
							
							<div class="user-wrapper">
								<img src="../assets/img/1.png" class="img-responsive" />
								<div class="description">
									<h4><?php echo $userRow['patientFirstName']; ?> <?php echo $userRow['patientLastName']; ?></h4>
									<h5> <strong> Work </strong></h5>
									<p>
									Input your details for work.
									</p>
									<hr />
									<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">Update Profile</button>
								</div>
							</div>
						</div>
						
						<div class="col-md-9 col-sm-9  user-wrapper">
							<div class="description">
								<h3> <?php echo $userRow['patientFirstName']; ?> <?php echo $userRow['patientLastName']; ?> </h3>
								<hr>		
								<div class="panel panel-default">
									<div class="panel-body">
										
										
										<table class="table table-user-information" align="center">
											<tbody>
												
												
												<tr>
													<td>Patient  Maritial  Status</td>
													<td><?php echo $userRow['patientMaritialStatus']; ?></td>
												</tr>
												<tr>
													<td>Patient DOB</td>
													<td><?php echo $userRow['patientDOB']; ?></td>
												</tr>
												<tr>
													<td>Patient Gender</td>
													<td><?php echo $userRow['patientGender']; ?></td>
												</tr>
												<tr>
													<td>Patient Address</td>
													<td><?php echo $userRow['patientAddress']; ?>
													</td>
												</tr>
												<tr>
													<td>Patient Phone</td>
													<td><?php echo $userRow['patientPhone']; ?>
													</td>
												</tr>
												<tr>
													<td>Patient Email</td>
													<td><?php echo $userRow['patientEmail']; ?>
													</td>
												</tr>
												<tr>
												<td colspan="2">
												<div class="card-container">
													<div class="card">
														<div class="front <?php echo $cardColorClass; ?>">
														<div class="card-details">
															<div class="first-row">
															<h3 class="bold">Medical Solutions</h3>
															<img alt="Brand" src="./assets/img/logo.png" class="card-logo-img" />
															<h3 class="bold">Smart Health Card</h3>
															</div>
															<div class="first-row">
															<img alt="Brand" src="./assets/img/chip.png" class="card-logo-img" />
															<p>Sponsered By <b> Tycoon Companies</b></p>
															<img alt="Brand" src="./assets/img/wifi.png" class="card-wifi-img" />
															</div>
															<div class="first-row">
															<h2 class="bold"><?php echo $userRow['patientFirstName']; ?> <?php echo $userRow['patientLastName']; ?></h2>
															<img alt="Brand" src="./assets/img/1.png" class="card-logo-img" />
															</div>
														</div>
														</div>
														<div class="back <?php echo $cardColorClass; ?>">
														<div class="back-details-main">
															<img alt="Brand" src="./assets/img/qr.png" class="card-qr-img" />
															<div class="back-details">
															<h2>Virtual Smart Card</h2>
															<p class="card-back-text">Cardholder Name: <?php echo $userRow['patientFirstName']; ?> <?php echo $userRow['patientLastName']; ?></p>
															<p class="card-back-text">IC Number: <?php echo $userRow['icPatient']; ?></p>
															<p class="card-back-text">Expiration Date: 12/24</p>
															<div class="cvv-block">
																<p class="card-back-text">CVV: <a class="cvv">•••</a></p>
																<p class="eye-icon card-back-text">Show / Hide</p>
															</div>
															</div>
														</div>
														</div>
													</div>
													</div>
													</td>
												</tr>
											</tbody>
										</table>
									</div>
								</div>
								
							</div>
							
						</div>
					</div>
					<!-- USER PROFILE ROW END-->
					<!-- end -->
					<div class="col-md-4">
						
						<!-- Large modal -->
						
						<!-- Modal -->
						<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
							<div class="modal-dialog" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										<h4 class="modal-title" id="myModalLabel">Personal Details</h4>
									</div>
									<div class="modal-body">
										<!-- form start -->
										<form action="<?php $_PHP_SELF ?>" method="post" >
											<table class="table table-user-information">
												<tbody>
													<tr>
														<td>IC Number:</td>
														<td><?php echo $userRow['icPatient']; ?></td>
													</tr>
													<tr>
														<td>First Name:</td>
														<td><input type="text" class="form-control" name="patientFirstName" value="<?php echo $userRow['patientFirstName']; ?>"  /></td>
													</tr>
													<tr>
														<td>Last Name</td>
														<td><input type="text" class="form-control" name="patientLastName" value="<?php echo $userRow['patientLastName']; ?>"  /></td>
													</tr>
													
													<!-- radio button -->
													<tr>
														<td>Maritial Status:</td>
														<td>
															<div class="radio">
																<label><input type="radio" name="patientMaritialStatus" value="single" <?php echo $single; ?>>Single</label>
															</div>
															<div class="radio">
																<label><input type="radio" name="patientMaritialStatus" value="married" <?php echo $married; ?>>Married</label>
															</div>
															<div class="radio">
																<label><input type="radio" name="patientMaritialStatus" value="separated" <?php echo $separated; ?>>Separated</label>
															</div>
															<div class="radio">
																<label><input type="radio" name="patientMaritialStatus" value="divorced" <?php echo $divorced; ?>>Divorced</label>
															</div>
															<div class="radio">
																<label><input type="radio" name="patientMaritialStatus" value="widowed" <?php echo $widowed; ?>>Widowed</label>
															</div>
														</td>
													</tr>
													<!-- radio button end -->
													<tr>
														<td>DOB</td>
														<!-- <td><input type="text" class="form-control" name="patientDOB" value="<?php echo $userRow['patientDOB']; ?>"  /></td> -->
														<td>
															<div class="form-group ">
																
																<div class="input-group">
																	<div class="input-group-addon">
																		<i class="fa fa-calendar">
																		</i>
																	</div>
																	<input class="form-control" id="patientDOB" name="patientDOB" placeholder="MM/DD/YYYY" type="text" value="<?php echo $userRow['patientDOB']; ?>"/>
																</div>
															</div>
														</td>
														
													</tr>
													<!-- radio button -->
													<tr>
														<td>Gender</td>
														<td>
															<div class="radio">
																<label><input type="radio" name="patientGender" value="male" <?php echo $male; ?>>Male</label>
															</div>
															<div class="radio">
																<label><input type="radio" name="patientGender" value="female" <?php echo $female; ?>>Female</label>
																<div class="radio">
																<label><input type="radio" name="patientGender" value="other" <?php echo $other; ?>>Other</label>
															</div>
														</td>
													</tr>
													<!-- radio button end -->
													
													<tr>
														<td>Phone number</td>
														<td><input type="text" class="form-control" name="patientPhone" value="<?php echo $userRow['patientPhone']; ?>"  /></td>
													</tr>
													<tr>
														<td>Email</td>
														<td><input type="text" class="form-control" name="patientEmail" value="<?php echo $userRow['patientEmail']; ?>"  /></td>
													</tr>
													<tr>
														<td>Address</td>
														<td><textarea class="form-control" name="patientAddress"  ><?php echo $userRow['patientAddress']; ?></textarea></td>
													</tr>
													<tr>
														<td>
															<input type="submit" name="submit" class="btn btn-info" value="Update Info"></td>
														</tr>
													</tbody>
													
												</table>
												
												
												
											</form>
											<!-- form end -->
										</div>
										
									</div>
								</div>
							</div>
							<br /><br/>
						</div>
						
					</div>
					<!-- ROW END -->
				</section>

				    <section class="section-cta" id="cta">
      <div class="container">
        <div class="popup_msg">
          <p class="popup_msg_text">
            Message is sent successfully, we will reach to you soon😊
          </p>
        </div>
        <div class="cta">
          <div class="cta-text-box">
            <h2 class="heading-secondary">Facing any difficulties or facing any problems?</h2>
            <p class="cta-text">
              If you find yourself encountering any difficulties or facing any problems, we're here to help. 
			  Please don't hesitate to reach out to us via email, and our dedicated support team will be ready 
			  to assist you with any issues or concerns you may have. Your satisfaction is our top priority, 
			  and we're committed to ensuring a smooth and hassle-free experience for you
            </p>

            <form
              class="cta-form"
              name="sign-up"
              onsubmit="sendMail(); reset(); return false;"
            >
              <div>
                <label for="full-name">Full Name</label>
                <input
                  id="full-name"
                  type="text"
                  placeholder="your name"
                  name="full-name"
                  required
                />
              </div>

              <div>
                <label for="email">Email address</label>
                <input
                  id="email"
                  type="email"
                  placeholder="me@example.com"
                  name="email"
                  required
                />
              </div>
              <button class="btn btn--form">Send</button>
            </form>
          </div>
          <div
            class="cta-img-box"
            role="img"
            
          ></div>
        </div>
      </div>
    </section>
				<!-- SECTION END -->
			</div>
			<!-- CONATINER END -->
			<script>
				document
				.querySelector(".card-container")
				.addEventListener("click", function () {
					this.classList.toggle("is-flipped");
				});

				document.querySelector(".eye-icon").addEventListener("click", function () {
				var cvv = document.querySelector(".cvv");
				if (cvv.textContent === "•••") {
					cvv.textContent = "123";
				} else {
					cvv.textContent = "•••";
				}
				});

			</script>
			    <script src="https://smtpjs.com/v3/smtp.js"></script>
				<script>
				const popup_container = document.querySelector(".popup_msg");
				const popup_msg = document.querySelector(".popup_msg_text");

				function sendMail() {
					Email.send({
					Host: "smtp.elasticemail.com",
					Username: "caretrackerhelp@outlook.com",
					Password: "AA023DADD1D6BBEB94D0C4B44B39D2FA045E",
					To: "infocaretracker@gmail.com",
					From: "caretrackerhelp@outlook.com",
					Subject: `${
						document.getElementById("full-name").value
					}, Wants to talk`,
					Body: `Mr/Mrs ${
						document.getElementById("full-name").value
					}, Wants to talk, contact them at ${
						document.getElementById("email").value
					}. \nHave a nice day :)`,
					}).then((message) => {
					popup_container.classList.add("show");
					setTimeout(() => {
						popup_container.classList.remove("show");
					}, 3000);
					});
				}
				</script>
			<script src="assets/js/jquery.js"></script>
			<script src="assets/js/bootstrap.min.js"></script>
			
			<script type="text/javascript">
			$(function () {
			$('#patientDOB').datetimepicker();
			});
			</script>

			<script>
				// Add an event listener to the insurancePlan dropdown
				document.getElementById("insurancePlan").addEventListener("change", function () {
					// Get the selected insurance plan
					var selectedPlan = this.value;
					var cardColorClass = "";

					// Calculate the card color based on the selected insurance plan
					if (selectedPlan === "Less than ₹20,000") {
						cardColorClass = "card-white";
					} else if (selectedPlan === "₹21,000 - ₹50,000") {
						cardColorClass = "card-silver";
					} else if (selectedPlan === "Above ₹50,000") {
						cardColorClass = "card-gold";
					}

					// Apply the updated card color to the card container
					var cardContainer = document.querySelector(".card");
					cardContainer.className = "card " + cardColorClass;
				});
			</script>
		</body>
	</html>