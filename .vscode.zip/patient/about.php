<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<title>About Us</title>
		<!-- Bootstrap -->
		<!-- <link href="assets/css/bootstrap.min.css" rel="stylesheet"> -->
		<link href="assets/css/material.css" rel="stylesheet">
		<link href="assets/css/default/style.css" rel="stylesheet">
		<!-- <link href="assets/css/default/style1.css" rel="stylesheet"> -->
		<link href="assets/css/default/blocks.css" rel="stylesheet">
		<link href="assets/css/index.css" rel="stylesheet"/>
		<link href="assets/css/date/bootstrap-datepicker.css" rel="stylesheet">
		<link href="assets/css/date/bootstrap-datepicker3.css" rel="stylesheet">
		<!-- Special version of Bootstrap that only affects content wrapped in .bootstrap-iso -->
		<!-- <link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" /> -->
		<!--Font Awesome (added because you use icons in your prepend/append)-->
		<link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css" />
		<!-- Bootstrap -->
		<link href="assets/css/bootstrap.min.css" rel="stylesheet">
		<link href="assets/css/default/style.css" rel="stylesheet">
		<link href="assets/style.css" rel="stylesheet">
		<!-- <link href="assets/css/default/style1.css" rel="stylesheet"> -->
		<link href="assets/css/default/blocks.css" rel="stylesheet">
		<link href="assets/css/date/bootstrap-datepicker.css" rel="stylesheet">
		<link href="assets/css/date/bootstrap-datepicker3.css" rel="stylesheet">
		<!-- Special version of Bootstrap that only affects content wrapped in .bootstrap-iso -->
		<link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" />
		<!--Font Awesome (added because you use icons in your prepend/append)-->
		<link rel="stylesheet" href="https://formden.com/static/cdn/font-awesome/4.4.0/css/font-awesome.min.css" />
		<!-- <link href="assets/css/material.css" rel="stylesheet"> -->
	</head>
	<body>
		
		<!-- navigation -->
		<nav class="navbar navbar-default " role="navigation">
			<div class="container-fluid">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="patient.php"><img alt="Brand" src="assets/img/logo.png" height="40px"></a>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<ul class="nav navbar-nav">
							<li><a href="patient.php">Home</a></li>
							<li><a href="insurance.php" target="_blank">Insurance</a></li>
							<li><a href="#cta" target="_blank">Contact Us</a></li>
						</ul>
					</ul>
				</div>
			</div>
		</nav>
		<!-- navigation -->
		
		<!-- 1st section start -->
			<div class="container">

            <div class="about-us">
                 <img src="assets/img/patient.gif" alt="doctor"/>
                 <div>
                    <h2>ABOUT US</h2>
                    <p>A comprehensive healthcare solution that focuses on the efficient and personalized care of patients throughout their healthcare journey. It encompasses a range of services and tools designed to streamline the patient experience, from appointment scheduling and medical record management to billing and follow-up care. By integrating technology and data-driven insights, patient management services aim to enhance communication between healthcare providers and their patients, optimize resource allocation, and improve the overall quality of care. These services not only benefit patients by providing a more seamless and patient-centric experience but also help healthcare organizations operate more efficiently and effectively in today's complex and dynamic healthcare landscape.</p>
                 </div>
            </div>

            </div>

		<div class="container">
		<!-- first section end -->
		<section class="section-cta" id="cta">
      <div class="container">
        <div class="popup_msg">
          <p class="popup_msg_text">
            Message is sent successfully, we will reach to you soon😊
          </p>
        </div>
        <div class="cta">
          <div class="cta-text-box">
            <h2 class="heading-secondary">CONTACT US</h2>
            
            <form
              class="cta-form"
              name="sign-up"
              onsubmit="sendMail(); reset(); return false;"
            >
              <div>
                <label for="full-name">Full Name</label>
                <input
                  id="full-name"
                  type="text"
                  placeholder="John Smith"
                  name="full-name"
                  required
                />
              </div>
              <div>
                <label for="email">Email address</label>
                <input
                  id="email"
                  type="email"
                  placeholder="me@example.com"
                  name="email"
                  required
                />
              </div>
              <button class="btn btn--form">Send</button>
            </form>
          </div>
        </div>
      </div>
 
	  <div class="social-media" style="margin:80px !important; text-align:center">
		<h3>OUR SOCIAL MEDIA</h3>
		<div class="accounts">
			<span class="fa fa-facebook"><a></a></span>
			
			<span class="fa fa-twitter"><a></a></span>
			
			<span class="fa fa-instagram"><a></a></span>
		</div>
	  </div>

    </section>

</div><script src="https://smtpjs.com/v3/smtp.js"></script>
				<script>
				const popup_container = document.querySelector(".popup_msg");
				const popup_msg = document.querySelector(".popup_msg_text");

				function sendMail() {
					Email.send({
					Host: "smtp.elasticemail.com",
					Username: "caretrackerhelp@outlook.com",
					Password: "AA023DADD1D6BBEB94D0C4B44B39D2FA045E",
					To: "infocaretracker@gmail.com",
					From: "caretrackerhelp@outlook.com",
					Subject: `${
						document.getElementById("full-name").value
					}, Wants to talk`,
					Body: `Mr/Mrs ${
						document.getElementById("full-name").value
					}, Wants to talk, contact them at ${
						document.getElementById("email").value
					}. \nHave a nice day :)`,
					}).then((message) => {
					popup_container.classList.add("show");
					setTimeout(() => {
						popup_container.classList.remove("show");
					}, 3000);
					});
				}
				</script>
		<!-- footer start -->
		<div class="copyright-bar bg-black">
			<div class="container">
				<p class="pull-left small">Patient Mangement System</p>
				<p class="pull-right small">Made with <i class="fa fa-heart pomegranate"></i> on Planet Earth</p>
			</div>
		</div>
		<!-- footer end -->
	
		<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
		<script src="assets/js/jquery.js"></script>
		<script src="assets/js/date/bootstrap-datepicker.js"></script>
		<script src="assets/js/moment.js"></script>
		<script src="assets/js/transition.js"></script>
		<script src="assets/js/collapse.js"></script>
		<!-- Include all compiled plugins (below), or include individual files as needed -->
		<script src="assets/js/bootstrap.min.js"></script>
	</body>
</html>