<?php
// Include necessary database connection code and session start
session_start();
include_once '../assets/conn/dbconnect.php';

if (!isset($_SESSION['patientSession'])) {
    header("Location: ../index.php");
}

// Retrieve user details and insurance information from the database
$res = mysqli_query($con, "SELECT * FROM patient WHERE icPatient=" . $_SESSION['patientSession']);
$userRow = mysqli_fetch_array($res, MYSQLI_ASSOC);

// Retrieve insurance information (you need to implement the logic for this)
$insuranceName = "InsuranceDekho";

// Replace with actual data

?>

<!DOCTYPE html>
<html lang="en">
<head>
    		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<title>Patient Dashboard</title>
		<!-- Bootstrap -->
		<!-- <link href="assets/css/bootstrap.min.css" rel="stylesheet"> -->
		<link href="assets/css/material.css" rel="stylesheet">
		<link href="assets/css/default/style.css" rel="stylesheet">
		<!-- <link href="assets/css/default/style1.css" rel="stylesheet"> -->
		<link href="assets/css/default/blocks.css" rel="stylesheet">
		<link href="assets/css/date/bootstrap-datepicker.css" rel="stylesheet">
		<link href="assets/css/date/bootstrap-datepicker3.css" rel="stylesheet">
		<link href="assets/css/insurance.css" rel="stylesheet">

		<!-- Special version of Bootstrap that only affects content wrapped in .bootstrap-iso -->
		<!-- <link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" /> -->
		<!--Font Awesome (added because you use icons in your prepend/append)-->
		<link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css" />
		
</head>
<body>
    		<!-- navigation -->
		<nav class="navbar navbar-default " role="navigation">
			<div class="container-fluid">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="patient.php"><img alt="Brand" src="assets/img/logo.png" height="40px"></a>
				</div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav">
						<ul class="nav navbar-nav">
							<li><a href="patient.php">Home</a></li>
							<!-- <li><a href="profile.php?patientId=<?php echo $userRow['icPatient']; ?>" >Profile</a></li> -->
							<li><a href="patientapplist.php?patientId=<?php echo $userRow['icPatient']; ?>">Appointment</a></li>
							<li><a href="insurance.php" target="_blank">Insurance</a></li>
						</ul>
					</ul>
					
					<ul class="nav navbar-nav navbar-right">
						<li class="dropdown">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> <?php echo $userRow['patientFirstName']; ?> <?php echo $userRow['patientLastName']; ?><b class="caret"></b></a>
							<ul class="dropdown-menu">
								<li>
									<a href="profile.php?patientId=<?php echo $userRow['icPatient']; ?>"><i class="fa fa-fw fa-user"></i> Profile</a>
								</li>
								<li>
									<a href="patientapplist.php?patientId=<?php echo $userRow['icPatient']; ?>"><i class="glyphicon glyphicon-file"></i> Appointment</a>
								</li>
								<li class="divider"></li>
								<li>
									<a href="patientlogout.php?logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
								</li>
							</ul>
						</li>
					</ul>
				</div>
			</div>
		</nav>
		<!-- navigation -->

    <div class="container">
            <div class="container-insurance">
                <div class="container-insurance-div">
                <h1 class="insurance-header">User Details and Insurance Information</h1>
                <p class="insurance-paragraph">Name: <?php echo $userRow['patientFirstName'] . ' ' . $userRow['patientLastName']; ?></p>
                <p class="insurance-paragraph">Age & DOB: 20 / 16-02-2003</p>
                <p class="insurance-paragraph">IC Number: <?php echo $userRow['icPatient']; ?></p>
                <p class="insurance-paragraph">Gender: <?php echo $userRow['patientGender']; ?></p>
                <p class="insurance-paragraph"><P><B>INSURANCE PLAN:</P></B> <P><B>LIC insurancePlan LIC insurance policies are succinctly named to denote their primary features and benefits. Examples include "Jeevan Anand" for combined insurance and savings, "Jeevan Labh" for limited premium endowment plans, and "e-Term" for online pure protection.</p></B>
                <p class="insurance-paragraph"><p><b>POLICY NAME:</p></b> <p><b>LIC PolicyPlan LIC offers diverse policies with names reflecting their features:
- Jeevan Anand: Blend of insurance and savings
- Jeevan Labh: Limited premium endowment plan
- New Endowment Plan: Maturity or death benefits
- e-Term: Online pure protection plan
- Jeevan Umang: Whole life assurance with income
- Cancer Cover: Lump sum for cancer diagnosis

Each policy caters to specific needs, from protection to savings and critical illness coverage.</p></b>

                <p class="insurance-paragraph"><p><b>POLICY PLAN: </b></p>: 
				<b>LIC PolicyPlan LIC offers various policy plans catering to different needs:

1. Term Insurance: Coverage for a specific term, with a lump sum benefit on death.
2. Endowment Plans: Combines insurance with savings, providing maturity or death benefits.
3. Whole Life Insurance: Lifetime coverage with savings component and death benefit.
4. ULIPs: Insurance with investment options, offering death benefit or fund value.
5. Money-Back Plans: Periodic payouts with insurance coverage and lump sum benefit.
6. Pension Plans: Provides regular income post-retirement with annuity options.

Choose a plan based on financial goals and needs, understanding its features and benefits.</b></p>
                <p class="insurance-paragraph"><p><b>INSURANCE VALIDITY:</p></b> <b>LIC insurance validity refers to the duration for which the policy remains active, offering coverage. It varies based on the type of policy, such as term, endowment, or whole life. Policyholders must pay premiums on time to avoid lapses. LIC provides various channels for managing policies and extending coverage. Understanding validity ensures continuous protection for policyholders and their families.</b></p>
    </div>
                 <img src="assets/img/lic image.png" alt="Insurance Life" />
            </div>
    </div>

    		<div class="copyright-bar bg-black">
			<div class="container">
				<p class="commandcentered">Patient Mangement System</p>
				
			</div>
		</div>

</body>
</html>



